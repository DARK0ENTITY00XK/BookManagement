package org.example;
public class Scanner {
}
